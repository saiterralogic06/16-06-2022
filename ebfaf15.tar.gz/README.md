# CI/CD

This repository is a collection of various scripts and tools that will be used to create some basic pipelines to test and deploy OSH. It is what AT&T may use for CI in the Dev environment.  More to come in the README.md of steps to take to get your Jenkins server to work with the scripts provided.

Sincerely,

AT&T Integrated Cloud Community Development Team


# Shared Libraries

Folder `vars` is used for shared functions across pipelines.

See more information for this plugin [here](https://jenkins.io/doc/book/pipeline/shared-libraries).

