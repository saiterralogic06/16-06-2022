#!/bin/bash

apt-get update
apt-get install -y default-jre-headless

